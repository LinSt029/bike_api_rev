from flask import Flask, request, jsonify
import sqlite3
import requests
from tqdm import tqdm
import json 
import numpy as np
import pandas as pd

app = Flask(__name__) 


@app.route('/')
def home():
    return 'Hello World'

@app.route('/stations/', methods=['GET'])
def route_all_stations():
    conn = make_connection()
    if conn is None:
        return jsonify({'error': 'Could not connect to database'}), 500
    try:
        stations = get_all_stations(conn)
        if stations.empty:
            return jsonify({"error": "No stations found"}), 404
        return jsonify(stations.to_dict(orient='records'))
    except Exception as e:
        return jsonify({"error": f"Error retrieving stations: {e}"}), 500
    finally:
        if conn:
            conn.close()

@app.route('/stations/<int:station_id>', methods=['GET'])
def route_station_id(station_id):
    conn = make_connection()
    if conn is None:
        return jsonify({'error': 'Could not connect to database'}), 500
    try:
        station = get_station_id(station_id, conn)
        if station.empty:
            return jsonify({"error": f"No station found with id {station_id}"}), 404
        return jsonify(station.to_dict(orient='records'))
    except Exception as e:
        return jsonify({"error": f"Error retrieving station: {e}"}), 500
    finally:
        if conn:
            conn.close()

@app.route('/stations/add', methods=['POST']) 
def route_add_station():
    # parse and transform incoming data into a tuple as we need 
    data = pd.Series(eval(request.get_json(force=True)))
    data = tuple(data.fillna('').values)
    
    conn = make_connection()
    result = insert_into_stations(data, conn)
    return result



@app.route('/trips/', methods=['GET'])
def route_all_trips():
    conn = make_connection()
    if conn is None:
        return jsonify({'error': 'Could not connect to database'}), 500
    try:
        trips = get_all_trips(conn)
        if trips.empty:
            return jsonify({"error": "No trips found"}), 404
        return jsonify(trips.to_dict(orient='records'))
    except Exception as e:
        return jsonify({"error": f"Error retrieving trips: {e}"}), 500
    finally:
        if conn:
            conn.close()

@app.route('/trips/<int:trip_id>', methods=['GET'])
def route_trip_id(trip_id):
    conn = make_connection()
    if conn is None:
        return jsonify({'error': 'Could not connect to database'}), 500
    try:
        trip = get_trip_id(trip_id, conn)
        if trip.empty:
            return jsonify({"error": f"No trip found with id {trip_id}"}), 404
        return jsonify(trip.to_dict(orient='records'))
    except Exception as e:
        return jsonify({"error": f"Error retrieving trip: {e}"}), 500
    finally:
        if conn:
            conn.close()

@app.route('/trips/add', methods=['POST']) 
def route_add_trips():
    # parse and transform incoming data into a tuple as we need 
    data = pd.Series(eval(request.get_json(force=True)))
    data = tuple(data.fillna('').values)
    
    conn = make_connection()
    result = insert_into_trips(data, conn)
    return result

@app.route('/trips/average_duration', methods=['GET'])
def route__average_trip_duration():
    conn = make_connection()
    if conn is None:
        return jsonify({'error': 'Could not connect to database'}), 500
    try:
        query = f"""SELECT AVG(duration_minutes) AS average_duration FROM trips"""
        result = pd.read_sql_query(query, conn)

        if result.empty or result['average_duration'].iloc[0] is None:
            return jsonify({"error": "No trips found"}), 404
    
        average_duration = result['average_duration'].iloc[0]
        return jsonify({"average_duration_minutes": round(average_duration, 2)}),200
    except Exception as e:
        return jsonify({"error": f"Error retrieving average duration: {e}"}), 500
    finally:
        if conn:
            conn.close()


@app.route('/trips/average_duration/<int:bike_id>', methods=['GET'])
def route__average_trip_duration_by_bike_id(bike_id):
    conn = make_connection()
    if conn is None:
        return jsonify({'error': 'Could not connect to database'}), 500
    try:
        query = f"""SELECT AVG(duration_minutes) AS average_duration FROM trips WHERE bike_id = {bike_id}"""
        result = pd.read_sql_query(query, conn, params=(bike_id,))

        if result.empty or result['average_duration'].iloc[0] is None:
            return jsonify({"error": "No trips found"}), 404
    
        average_duration = result['average_duration'].iloc[0]
        return jsonify({"average_duration_minutes": round(average_duration, 2)}),200
    except Exception as e:
        logging.error(f"Error calculating average duration for Bike ID {bike_id}: {str(e)}")
        return jsonify({"error": f"An error occurred: {str(e)}"}), 500
    finally:
        if conn:
            conn.close()

@app.route('/trips/rental_activities_v2', methods=['POST'])
def route_rental_activities_v2():
    try:
        input_data = request.get_json()
        if not input_data or 'period' not in input_data:
            return jsonify({"error": "Invalid input. Please provide correct information"}), 400
        
        specified_date = input_data['period']
        logging.info(f"Received period: {specified_date}")

        conn = make_connection()
        if conn is None:
            return jsonify({'error': 'Could not connect to database'}), 500
        
        query = f"""
                SELECT startstationid, startstationname, bikeid, duration_minutes
                FROM trips
                WHERE start_time LIKE '{specified_date}%'
                ORDER BY duration_minutes DESC"""
        params = (f"{specified_date}%",)
        selected_data = pd.read_sql_query(query, conn, params=params)

        if selected_data.empty:
            return jsonify({"error": f"No rental activities found in {specified_date}"}), 404
        
        result = selected_data.groupby(['startstationid', 'startstationname']).agg({
            'bikeid': 'count',
            'duration_minutes': ['mean']}).reset_index()
        
        result.rename(columns={'bikeid': 'rental_count', 'duration_minutes': 'average_duration_minutes'}, inplace=True)
        return jsonify(result.to_dict(orient='records')), 200
    
    except Exception as e:
        logging.error(f"error in /trips/rental_activities_v2: {str(e)}")
        return jsonify({"error": f"Error in /trips/rental_activities_v2: {str(e)}"}), 500
    

####################################### FUNCTIONS #########################################


def get_all_stations(conn):
    query = """SELECT * FROM stations"""
    result = pd.read_sql_query(query, conn)
    return result

def get_station_id(station_id, conn):
    query = """SELECT * FROM stations WHERE station_id = ?"""
    return pd.read_sql_query(query, conn, params=(station_id,))

def insert_into_stations(data, conn):
    query = f"""INSERT INTO stations values {data}"""
    try:
        conn.execute(query, data)
        conn.commit()
        return 'OK'
    except sqlite3.Error as e:
        conn.rollback()
        return {"success" : False, "error" : str(e)}

def insert_into_stations(data, conn):
    query = f"""INSERT INTO stations values {data}"""
    try:
        conn.execute(query, data)
        conn.commit()
        return 'OK'
    except sqlite3.Error as e:
        conn.rollback()
        return {"success" : False, "error" : str(e)}



def get_all_trips(conn):
    query = """SELECT * FROM trips"""
    result = pd.read_sql_query(query, conn)
    return result

def get_trip_id(trip_id, conn):
    query = """SELECT * FROM trips WHERE trip_id = ?"""
    return pd.read_sql_query(query, conn, params=(trip_id,))

def insert_into_trips(data, conn):
    query = f"""INSERT INTO trips values {data}"""
    try:
        conn.execute(query, data)
        conn.commit()
        return 'OK'
    except sqlite3.Error as e:
        conn.rollback()
        return {"success" : False, "error" : str(e)}
    

def make_connection():
    try:
        connection = sqlite3.connect('austin_bikeshare.db')
        return connection
    except Exception as e:
        print(f"Error connecting to database: {str(e)}")
        return None

if __name__ == '__main__':
    app.run(debug=True, port=5000)